#ifndef OMEGATOOLS_HH
#define OMEGATOOLS_HH

#include <string>
#include <omega.h>
#include "dep.hh"
#include "ir_code.hh"

std::string tmp_e();

void exp2formula(IR_Code *ir, omega::Relation &r, omega::F_And *f_root,
                 std::vector<omega::Free_Var_Decl *> &freevars,
                 omega::CG_outputRepr *repr, omega::Variable_ID lhs, char side,
                 IR_CONDITION_TYPE rel, bool destroy);
omega::Relation arrays2relation(IR_Code *ir, std::vector<omega::Free_Var_Decl*> &freevars,
                                const IR_ArrayRef *ref_src, const omega::Relation &IS_w,
                                const IR_ArrayRef *ref_dst, const omega::Relation &IS_r);
std::pair<std::vector<DependenceVector>, std::vector<DependenceVector> > relation2dependences(
  const IR_ArrayRef *ref_src, const IR_ArrayRef *ref_dst, const omega::Relation &r);

void exp2constraint(IR_Code *ir, omega::Relation &r, omega::F_And *f_root,
                    std::vector<omega::Free_Var_Decl *> &freevars,
                    omega::CG_outputRepr *repr, bool destroy);


bool is_single_iteration(const omega::Relation &r, int dim);
void assign_const(omega::Relation &r, int dim, int val);
int get_const(const omega::Relation &r, int dim, omega::Var_Kind type);
omega::Variable_ID find_index(omega::Relation &r, const std::string &s, char side);
omega::Relation permute_relation(const std::vector<int> &pi);
omega::Relation get_loop_bound(const omega::Relation &r, int dim);
bool is_single_loop_iteration(const omega::Relation &r, int level, const omega::Relation &known);
omega::Relation get_loop_bound(const omega::Relation &r, int level, const omega::Relation &known);
omega::Relation get_max_loop_bound(const std::vector<omega::Relation> &r, int dim);
omega::Relation get_min_loop_bound(const std::vector<omega::Relation> &r, int dim);
void add_loop_stride(omega::Relation &r, const omega::Relation &bound, int dim, int stride);
bool is_inner_loop_depend_on_level(const omega::Relation &r, int level, const omega::Relation &known);
omega::Relation adjust_loop_bound(const omega::Relation &r, int level, int adjustment);


enum LexicalOrderType {LEX_MATCH, LEX_BEFORE, LEX_AFTER, LEX_UNKNOWN};


#endif
