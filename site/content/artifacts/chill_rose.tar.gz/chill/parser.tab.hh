
/* A Bison parser, made by GNU Bison 2.4.1.  */

/* Skeleton interface for Bison's Yacc-like parsers in C
   
      Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.
   
   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.
   
   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */


/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     NUMBER = 258,
     LEVEL = 259,
     TRUEORFALSE = 260,
     FILENAME = 261,
     PROCEDURENAME = 262,
     VARIABLE = 263,
     FREEVAR = 264,
     SOURCE = 265,
     PROCEDURE = 266,
     FORMAT = 267,
     LOOP = 268,
     PERMUTE = 269,
     ORIGINAL = 270,
     TILE = 271,
     UNROLL = 272,
     SPLIT = 273,
     UNROLL_EXTRA = 274,
     DATACOPY = 275,
     DATACOPY_PRIVATIZED = 276,
     NONSINGULAR = 277,
     EXIT = 278,
     KNOWN = 279,
     SKEW = 280,
     SHIFT = 281,
     SHIFT_TO = 282,
     FUSE = 283,
     DISTRIBUTE = 284,
     REMOVE_DEP = 285,
     SCALE = 286,
     REVERSE = 287,
     PEEL = 288,
     STRIDED = 289,
     COUNTED = 290,
     NUM_STATEMENT = 291,
     CEIL = 292,
     FLOOR = 293,
     PRINT = 294,
     PRINT_CODE = 295,
     PRINT_DEP = 296,
     PRINT_IS = 297,
     PRINT_STRUCTURE = 298,
     NE = 299,
     LE = 300,
     GE = 301,
     EQ = 302,
     UMINUS = 303
   };
#endif



#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
{

/* Line 1676 of yacc.c  */
#line 63 "parser.yy"

  int val;
  float fval;
  bool bool_val;
  char *name;
  std::vector<int> *vec;
  std::vector<std::vector<int> > *mat;
  std::map<std::string, int> *tab;
  std::vector<std::map<std::string, int> > *tab_lst;
  std::pair<std::vector<std::map<std::string, int> >, std::map<std::string, int> > *eq_term_pair;



/* Line 1676 of yacc.c  */
#line 114 "parser.tab.hh"
} YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
#endif

extern YYSTYPE yylval;


