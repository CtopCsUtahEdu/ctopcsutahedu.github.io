
/* A Bison parser, made by GNU Bison 2.4.1.  */

/* Skeleton interface for Bison's Yacc-like parsers in C
   
      Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.
   
   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.
   
   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */


/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     NUMBER = 258,
     LEVEL = 259,
     TRUEORFALSE = 260,
     FILENAME = 261,
     VARIABLE = 262,
     FREEVAR = 263,
     SOURCE = 264,
     PROCEDURE = 265,
     FORMAT = 266,
     LOOP = 267,
     PERMUTE = 268,
     ORIGINAL = 269,
     TILE = 270,
     UNROLL = 271,
     SPLIT = 272,
     UNROLL_EXTRA = 273,
     DATACOPY = 274,
     DATACOPY_PRIVATIZED = 275,
     NONSINGULAR = 276,
     STOP = 277,
     SKEW = 278,
     SHIFT = 279,
     SHIFT_TO = 280,
     FUSE = 281,
     DISTRIBUTE = 282,
     SCALE = 283,
     REVERSE = 284,
     PEEL = 285,
     KNOWN = 286,
     REMOVE_DEP = 287,
     STRIDED = 288,
     COUNTED = 289,
     NUM_STATEMENT = 290,
     CEIL = 291,
     FLOOR = 292,
     PRINT = 293,
     PRINT_CODE = 294,
     PRINT_DEP = 295,
     PRINT_IS = 296,
     NE = 297,
     LE = 298,
     GE = 299,
     EQ = 300,
     UMINUS = 301
   };
#endif



#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
{

/* Line 1676 of yacc.c  */
#line 62 "parser.yy"

  int val;
  float fval;
  bool bool_val;
  char *name;
  std::vector<int> *vec;
  std::vector<std::vector<int> > *mat;
  std::map<std::string, int> *tab;
  std::vector<std::map<std::string, int> > *tab_lst;
  std::pair<std::vector<std::map<std::string, int> >, std::map<std::string, int> > *eq_term_pair;



/* Line 1676 of yacc.c  */
#line 112 "parser.tab.hh"
} YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
#endif

extern YYSTYPE yylval;


