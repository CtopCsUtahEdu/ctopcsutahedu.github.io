/*****************************************************************************
 Copyright (C) 2004-2011 Chun Chen
 All Rights Reserved.

 Purpose:
   Loop class core functionality.

 Notes:
   "level" (starting from 1) means loop level and it corresponds to "dim"
 (starting from 0) in transformed iteration space [c_1,l_1,c_2,l_2,....,
 c_n,l_n,c_(n+1)], e.g., l_2 is loop level 2 in generated code, dim 3
 in transformed iteration space, and variable 4 in Omega relation.
 All c's are constant numbers only and they will not show up as actual loops.
 Formula:
    dim = 2*level - 1
    var = dim + 1

   Every transformation algorithm needs to invalidate previous code
 generation result mesmorized as mutable members if ever they exist.
 
 History:
   10/01/05 Created by Chun Chen.
   10/20/09 Initialize unfusible loop nest without bailing out, -chun
*****************************************************************************/

#include <limits.h>
#include <codegen.h>
#include <code_gen/CG_utils.h>
#include <iostream>
#include <map>
#include "loop.hh"
#include "omegatools.hh"
#include "irtools.hh"
#include "chill_error.hh"

using namespace omega;

const std::string Loop::tmp_loop_var_name_prefix = std::string("_t");
const std::string Loop::overflow_var_name_prefix = std::string("over");

//-----------------------------------------------------------------------------
// Class Loop
//-----------------------------------------------------------------------------

bool Loop::init_loop(std::vector<ir_tree_node *> &ir_tree, std::vector<ir_tree_node *> &ir_stmt) {
  ir_stmt = extract_ir_stmts(ir_tree);
  std::vector<int> stmt_nesting_level(ir_stmt.size());
  for (int i = 0; i < ir_stmt.size(); i++) {
    ir_stmt[i]->payload = i;
    int t = 0;
    ir_tree_node *itn = ir_stmt[i];
    while (itn->parent != NULL) {
      itn = itn->parent;
      if (itn->content->type() == IR_CONTROL_LOOP)
        t++;
    }
    stmt_nesting_level[i] = t;
  }

  stmts_ = std::vector<Statement>(ir_stmt.size());
  int n_dim = -1;
  int max_loc;
  std::vector<std::string> index;
  for (int i = 0; i < ir_stmt.size(); i++) {
    int max_nesting_level = -1;
    int loc;
    for (int j = 0; j < ir_stmt.size(); j++)
      if (stmt_nesting_level[j] > max_nesting_level) {
        max_nesting_level = stmt_nesting_level[j];
        loc = j;
      }

    // most deeply nested statement acting as a reference point
    if (n_dim == -1) {
      n_dim = max_nesting_level;
      max_loc = loc;

      index = std::vector<std::string>(n_dim);
      
      ir_tree_node *itn = ir_stmt[loc];
      int cur_dim = n_dim-1;
      while (itn->parent != NULL) {
        itn = itn->parent;
        if (itn->content->type() == IR_CONTROL_LOOP) {
          index[cur_dim] = static_cast<IR_Loop *>(itn->content)->index()->name();
          itn->payload = cur_dim--;
        }
      }
    }

    // align loops by names, temporary solution
    ir_tree_node *itn = ir_stmt[loc];
    while (itn->parent != NULL) {
      itn = itn->parent;
      if (itn->content->type() == IR_CONTROL_LOOP && itn->payload == -1) {
        std::string name = static_cast<IR_Loop *>(itn->content)->index()->name();
        for (int j = 0; j < n_dim; j++)
          if (index[j] == name) {
            itn->payload = j;
            break;
          }
        if (itn->payload == -1)
          throw loop_error("no complex alignment yet");
      }
    }

    // set relation variable names
    Relation r(n_dim);
    F_And *f_root = r.add_and();
    itn = ir_stmt[loc];
    while (itn->parent != NULL) {
      itn = itn->parent;
      if (itn->content->type() == IR_CONTROL_LOOP)
        r.name_set_var(itn->payload+1, static_cast<IR_Loop *>(itn->content)->index()->name());
    }

    // extract information from loop/if structures
    std::vector<bool> processed(n_dim, false);
    std::vector<std::string> vars_to_be_reversed;
    itn = ir_stmt[loc];
    while (itn->parent != NULL) {
      itn = itn->parent;
      
      switch (itn->content->type()) {
      case IR_CONTROL_LOOP: {
        IR_Loop *lp = static_cast<IR_Loop *>(itn->content);
        Variable_ID v = r.set_var(itn->payload+1);
        int c;
        
        try {
          c = lp->step_size();
          if (c > 0) {
            CG_outputRepr *lb = lp->lower_bound();
            exp2formula(ir_, r, f_root, freevar, lb, v, 's', IR_COND_GE, true);
            CG_outputRepr *ub = lp->upper_bound();
            IR_CONDITION_TYPE cond = lp->stop_cond();
            if (cond == IR_COND_LT || cond == IR_COND_LE)
              exp2formula(ir_, r, f_root, freevar, ub, v, 's', cond, true);
            else
              throw ir_error("loop condition not supported");

          }
          else if (c < 0) {
            CG_outputBuilder *ocg = ir_->builder();
            CG_outputRepr *lb = lp->lower_bound();
            lb = ocg->CreateMinus(NULL, lb);
            exp2formula(ir_, r, f_root, freevar, lb, v, 's', IR_COND_GE, true);
            CG_outputRepr *ub = lp->upper_bound();
            ub = ocg->CreateMinus(NULL, ub);
            IR_CONDITION_TYPE cond = lp->stop_cond();
            if (cond == IR_COND_GE)
              exp2formula(ir_, r, f_root, freevar, ub, v, 's', IR_COND_LE, true);
            else if (cond == IR_COND_GT)
              exp2formula(ir_, r, f_root, freevar, ub, v, 's', IR_COND_LT, true);
            else
              throw ir_error("loop condition not supported");

            vars_to_be_reversed.push_back(lp->index()->name());
          }
          else
            throw ir_error("loop step size zero");
        }
        catch (const ir_error &e) {
          for (int i = 0; i < itn->children.size(); i++)
            delete itn->children[i];
          itn->children = std::vector<ir_tree_node *>();
          itn->content = itn->content->convert();
          return false;
        }
        
        if (abs(c) != 1) {
          F_Exists *f_exists = f_root->add_exists();
          Variable_ID e = f_exists->declare();
          F_And *f_and = f_exists->add_and();
          Stride_Handle h = f_and->add_stride(abs(c));
          if (c > 0)
            h.update_coef(e, 1);
          else
            h.update_coef(e, -1);
          h.update_coef(v, -1);
          CG_outputRepr *lb = lp->lower_bound();
          exp2formula(ir_, r, f_and, freevar, lb, e, 's', IR_COND_EQ, true);
        }
          
        processed[itn->payload] = true;
        break;
      }
      case IR_CONTROL_IF: {
        CG_outputRepr *cond = static_cast<IR_If *>(itn->content)->condition();
        try {
          if (itn->payload % 2 == 1)
            exp2constraint(ir_, r, f_root, freevar, cond, true);
          else {
            F_Not *f_not = f_root->add_not();
            F_And *f_and = f_not->add_and();
            exp2constraint(ir_, r, f_and, freevar, cond, true);
          }
        }
        catch (const ir_error &e) {
          std::vector<ir_tree_node *> *t;
          if (itn->parent == NULL)
            t = &ir_tree;
          else
            t = &(itn->parent->children);
          int id = itn->payload;
          int i = t->size() - 1;
          while (i >= 0) {
            if ((*t)[i] == itn) {
              for (int j = 0; j < itn->children.size(); j++)
                delete itn->children[j];
              itn->children = std::vector<ir_tree_node *>();
              itn->content = itn->content->convert();
            }
            else if ((*t)[i]->payload >> 1 == id >> 1) {
              delete (*t)[i];
              t->erase(t->begin()+i);
            }
            i--;
          }
          return false;
        }
          
        break;
      }
      default:
        for (int i = 0; i < itn->children.size(); i++)
          delete itn->children[i];
        itn->children = std::vector<ir_tree_node *>();
        itn->content = itn->content->convert();
        return false;
      }
    }

    // add information for missing loops
    for (int j = 0; j < n_dim; j++)
      if (!processed[j]) {
        ir_tree_node *itn = ir_stmt[max_loc];
        while (itn->parent != NULL) {
          itn = itn->parent;
          if (itn->content->type() == IR_CONTROL_LOOP && itn->payload == j)
            break;
        }

        Variable_ID v = r.set_var(j+1);
        if (loc < max_loc) {
          CG_outputRepr *lb = static_cast<IR_Loop *>(itn->content)->lower_bound();
          exp2formula(ir_, r, f_root, freevar, lb, v, 's', IR_COND_EQ, true);
        }
        else { // loc > max_loc
          CG_outputRepr *ub = static_cast<IR_Loop *>(itn->content)->upper_bound();
          exp2formula(ir_, r, f_root, freevar, ub, v, 's', IR_COND_EQ, true);
        }
      }

    r.setup_names();
    r.simplify();
    
    // insert the statement
    CG_outputBuilder *ocg = ir_->builder();
    std::vector<CG_outputRepr *> reverse_expr;
    for (int j = 0; j < vars_to_be_reversed.size(); j++) {
      CG_outputRepr *repl = ocg->CreateIdent(vars_to_be_reversed[j]);
      repl = ocg->CreateMinus(NULL, repl);
      reverse_expr.push_back(repl);
    }     
    CG_outputRepr *code = static_cast<IR_Block *>(ir_stmt[loc]->content)->extract();
    code = ocg->CreateSubstitutedStmt(0, code, vars_to_be_reversed, reverse_expr);
    stmts_[loc].code = code;
    stmts_[loc].IS = r;
    stmts_[loc].levels = std::vector<std::pair<LoopLevelType, int> >(n_dim);
    for (int i = 0; i < n_dim; i++) {
      stmts_[loc].levels[i].first = NativeLevel;
      stmts_[loc].levels[i].second = i;
    }
    
    stmt_nesting_level[loc] = -1;
  }

  return true;
}  



Loop::Loop(const IR_Control *control) {
  last_compute_cgr_ = NULL;
  last_compute_cg_ = NULL;
  ir_ = const_cast<IR_Code *>(control->ir_);
  init_code_ = NULL;
  cleanup_code_ = NULL;
  tmp_loop_var_name_counter = 1;
  overflow_var_name_counter = 1;
  known_ = Relation::True(0);

  std::vector<ir_tree_node *> ir_tree = build_ir_tree(control->clone(), NULL);
  std::vector<ir_tree_node *> ir_stmt;

  while (!init_loop(ir_tree, ir_stmt)) {}

  if (stmts_.size() != 0)
    dep_ = DependenceGraph(stmts_[0].IS.n_set());
  else
    dep_ = DependenceGraph(0);

  // init the dependence graph
  for (int i = 0; i < stmts_.size(); i++)
    dep_.insert();

  for (int i = 0; i < stmts_.size(); i++)
    for (int j = i; j < stmts_.size(); j++) {
      std::pair<std::vector<DependenceVector>, std::vector<DependenceVector> > dv = test_data_dependences(ir_, stmts_[i].code, stmts_[i].IS, stmts_[j].code, stmts_[j].IS, freevar);
      
      for (int k = 0; k < dv.first.size(); k++)
        if (is_dependence_valid(ir_stmt[i], ir_stmt[j], dv.first[k], true))
          dep_.connect(i, j, dv.first[k]);
        else
          dep_.connect(j, i, dv.first[k].reverse());

      for (int k = 0; k < dv.second.size(); k++)
        if (is_dependence_valid(ir_stmt[j], ir_stmt[i], dv.second[k], false))
          dep_.connect(j, i, dv.second[k]);
        else
          dep_.connect(i, j, dv.second[k].reverse());
    }

  // cleanup the IR tree
  for (int i = 0; i < ir_tree.size(); i++)
    delete ir_tree[i];
    
  // init dumb transformation relations e.g. [i, j] -> [ 0, i, 0, j, 0]
  for (int i = 0; i < stmts_.size(); i++) {
    int n = stmts_[i].IS.n_set();
    stmts_[i].xform = Relation(n, 2*n+1);
    F_And *f_root = stmts_[i].xform.add_and();
    
    for (int j = 1; j <= n; j++) {
      EQ_Handle h = f_root->add_EQ();
      h.update_coef(stmts_[i].xform.output_var(2*j), 1);
      h.update_coef(stmts_[i].xform.input_var(j), -1);
    }

    for (int j = 1; j <= 2*n+1; j+=2) {
      EQ_Handle h = f_root->add_EQ();
      h.update_coef(stmts_[i].xform.output_var(j), 1);
    }
    stmts_[i].xform.simplify();
  }
}


Loop::~Loop() {
  delete last_compute_cgr_;
  delete last_compute_cg_;
  
  for (int i = 0; i < stmts_.size(); i++)
    if (stmts_[i].code != NULL) {
      stmts_[i].code->clear();
      delete stmts_[i].code;
    }
  if (init_code_ != NULL) {
    init_code_->clear();
    delete init_code_;
  }
  if (cleanup_code_ != NULL) {
    cleanup_code_->clear();
    delete cleanup_code_;
  }
}


bool Loop::isInitialized() const {
  return stmts_.size() != 0 && !stmts_[0].xform.is_null();
}


int Loop::get_dep_dim_of(int stmt_num, int level) const {
  if (stmt_num < 0 || stmt_num >= stmts_.size())
    throw std::invalid_argument("invaid statement " + to_string(stmt_num));
  
  if (level < 1 || level > stmts_[stmt_num].levels.size())
    return -1;

  int trip_count = 0;
  while (true) {
    switch (stmts_[stmt_num].levels[level-1].first) {
    case NativeLevel:
      return stmts_[stmt_num].levels[level-1].second;
    case BlockLevel:
      level = stmts_[stmt_num].levels[level-1].second;
      assert(level > 0);
      if (level > stmts_[stmt_num].levels.size())
        throw loop_error("incorrect loop level information for statement " + to_string(stmt_num));
      break;
    default:
      throw loop_error("unknown loop level information for statement " + to_string(stmt_num));
    }
    trip_count++;
    if (trip_count >= stmts_[stmt_num].levels.size())
      throw loop_error("incorrect loop level information for statement " + to_string(stmt_num));
  }
}


int Loop::get_last_dep_dim_before(int stmt_num, int level) const {
  if (stmt_num < 0 || stmt_num >= stmts_.size())
    throw std::invalid_argument("invaid statement " + to_string(stmt_num));

  if (level < 1)
    return -1;
  if (level > stmts_[stmt_num].levels.size())
    level = stmts_[stmt_num].levels.size() + 1;
  
  for (int i = level-1; i >= 1; i--)
    if (stmts_[stmt_num].levels[i-1].first == NativeLevel)
      return stmts_[stmt_num].levels[i-1].second;

  return -1;
}


void Loop::dump() const {
  for (int i = 0; i < stmts_.size(); i++) {
    std::vector<int> lex = getLexicalOrder(i);
    std::cout << "s" << i+1 << ": ";
    for (int j = 0; j < stmts_[i].levels.size(); j++) {
      if (2*j < lex.size())
        std::cout << lex[2*j];
      switch (stmts_[i].levels[j].first) {
      case NativeLevel:
        std::cout << "(dim:" << stmts_[i].levels[j].second << ")";
        break;
      case BlockLevel:
        std::cout << "(tile:" << stmts_[i].levels[j].second << ")";
        break;
      default:
        std::cout << "(unknown)";
      }
      std::cout << ' ';
    }
    for (int j = 2*stmts_[i].levels.size(); j < lex.size(); j+=2) {
      std::cout << lex[j];
      if (j != lex.size()-1)
        std::cout << ' ';
    }
    std::cout << std::endl;
  }
}
  
   
CG_outputRepr *Loop::getCode(int effort) const {
  const int m = stmts_.size();
  if (m == 0)
    return NULL;
  const int n = stmts_[0].xform.n_out();

  if (last_compute_cg_ == NULL) {
    std::vector<Relation> IS(m);
    std::vector<Relation> xforms(m);
    for (int i = 0; i < m; i++) {
      IS[i] = stmts_[i].IS;
      xforms[i] = stmts_[i].xform;
    }
    Relation known = Extend_Set(copy(known_), n - known_.n_set());  

    last_compute_cg_ = new CodeGen(xforms, IS, known);
    delete last_compute_cgr_;
    last_compute_cgr_ = NULL;
  }

  if (last_compute_cgr_ == NULL || last_compute_effort_ != effort) {
    delete last_compute_cgr_;
    last_compute_cgr_ = last_compute_cg_->buildAST(effort);
    last_compute_effort_ = effort;
  }
  
  std::vector<CG_outputRepr *> stmts(m);
  for (int i = 0; i < m; i++)
    stmts[i] = stmts_[i].code;
  CG_outputBuilder *ocg = ir_->builder();
  CG_outputRepr *repr = last_compute_cgr_->printRepr(ocg, stmts);

  if (init_code_ != NULL)
    repr = ocg->StmtListAppend(init_code_->clone(), repr);
  if (cleanup_code_ != NULL)
    repr = ocg->StmtListAppend(repr, cleanup_code_->clone());
  
  return repr;
}


void Loop::printCode(int effort) const {
  const int m = stmts_.size();
  if (m == 0)
    return;
  const int n = stmts_[0].xform.n_out();

  if (last_compute_cg_ == NULL) {
    std::vector<Relation> IS(m);
    std::vector<Relation> xforms(m);
    for (int i = 0; i < m; i++) {
      IS[i] = stmts_[i].IS;
      xforms[i] = stmts_[i].xform;
    }
    Relation known = Extend_Set(copy(known_), n - known_.n_set());

    last_compute_cg_ = new CodeGen(xforms, IS, known);
    delete last_compute_cgr_;
    last_compute_cgr_ = NULL;
  }

  if (last_compute_cgr_ == NULL || last_compute_effort_ != effort) {
    delete last_compute_cgr_;
    last_compute_cgr_ = last_compute_cg_->buildAST(effort);
    last_compute_effort_ = effort;
  }
  
  std::string repr = last_compute_cgr_->printString();
  std::cout << repr << std::endl;
}


void Loop::printIterationSpace() const {
  for (int i = 0; i < stmts_.size(); i++) {
    std::cout << "s" << i << ": ";
    Relation r = getNewIS(i);
    for (int j = 1; j <= r.n_inp(); j++)
      r.name_input_var(j, CodeGen::loop_var_name_prefix + to_string(j));
    r.setup_names();
    r.print();
  }
}


void Loop::printDependenceGraph() const {
  if (dep_.edgeCount() == 0)
    std::cout << "no dependence exists" << std::endl;
  else {
    std::cout << "dependence graph:" << std::endl;
    std::cout << dep_;
  }
}
  

Relation Loop::getNewIS(int stmt_num) const {
  Relation result;
  
  if (stmts_[stmt_num].xform.is_null()) {
    Relation known = Extend_Set(copy(known_), stmts_[stmt_num].IS.n_set() - known_.n_set());
    result = Intersection(copy(stmts_[stmt_num].IS), known);
  }
  else {
    Relation known = Extend_Set(copy(known_), stmts_[stmt_num].xform.n_out() - known_.n_set()); 
    result = Intersection(Range(Restrict_Domain(copy(stmts_[stmt_num].xform), copy(stmts_[stmt_num].IS))), known);
  }
  
  result.simplify(2, 4);

  return result;
}
  


std::vector<int> Loop::getLexicalOrder(int stmt_num) const {
  assert(stmt_num < stmts_.size());
         
  const int n = stmts_[stmt_num].xform.n_out();
  std::vector<int> lex(n,0);

  for (int i = 0; i < n; i += 2)
    lex[i] = get_const(stmts_[stmt_num].xform, i, Output_Var);

  return lex;
}


std::set<int> Loop::getStatements(const std::vector<int> &lex, int dim) const {
  const int m = stmts_.size();
  
  std::set<int> same_loops;
  for (int i = 0; i < m; i++) {
    if (dim < 0)
      same_loops.insert(i);
    else {
      std::vector<int> a_lex = getLexicalOrder(i);
      int j;
      for (j = 0; j <= dim; j+=2)
        if (lex[j] != a_lex[j])
          break;
      if (j > dim)
        same_loops.insert(i);
    }
  }

  return same_loops;
}


// find the sub loop nest specified by stmt_num and level,
// only iteration space satisfiable statements returned.
std::set<int> Loop::getSubLoopNest(int stmt_num, int level) const {
  assert(stmt_num >= 0 && stmt_num < stmts_.size());
  assert(level > 0 && level <= stmts_[stmt_num].levels.size());
  
  std::set<int> working;
  for (int i = 0; i < stmts_.size(); i++)
    if (const_cast<Loop *>(this)->stmts_[i].IS.is_upper_bound_satisfiable() &&
        stmts_[i].levels.size() >= level)
      working.insert(i);

  for (int i = 1; i <= level; i++) {
    int a = getLexicalOrder(stmt_num, i);
    for (std::set<int>::iterator j = working.begin(); j != working.end(); ) {
      int b = getLexicalOrder(*j, i);
      if (b != a)
        working.erase(j++);
      else
        ++j;
    }
  }

  return working;
}


// if level is greater than number of levels, it means lexical order
// inside the innermost loop.
int Loop::getLexicalOrder(int stmt_num, int level) const {
  assert(stmt_num >= 0 && stmt_num < stmts_.size());
  assert(level > 0 && level <= stmts_[stmt_num].levels.size()+1);

  Relation &r = const_cast<Loop *>(this)->stmts_[stmt_num].xform;
  for (EQ_Iterator e(r.single_conjunct()->EQs()); e; e++)
    if (abs((*e).get_coef(r.output_var(2*level-1))) == 1) {
      bool is_const = true;
      for (Constr_Vars_Iter cvi(*e); cvi; cvi++)
        if (cvi.curr_var() != r.output_var(2*level-1)) {
          is_const = false;
          break;
        }
      if (is_const) {
        int t = static_cast<int>((*e).get_const());
        return (*e).get_coef(r.output_var(2*level-1))>0?-t:t;
      }
    }

  throw loop_error("can't find lexical order for statement " + to_string(stmt_num) + "'s loop level " + to_string(level));
}

  
void Loop::shiftLexicalOrder(const std::vector<int> &lex, int dim, int amount) {
  const int m = stmts_.size();

  if (amount == 0)
    return;
  
  for (int i = 0; i < m; i++) {
    std::vector<int> lex2 = getLexicalOrder(i);

    bool need_shift = true;
    
    for (int j = 0; j < dim; j++)
      if (lex2[j] != lex[j]) {
        need_shift = false;
        break;
      }

    if (!need_shift)
      continue;
    
    if (amount > 0) {
      if (lex2[dim] < lex[dim])
        continue;
    }
    else if (amount < 0) {
      if (lex2[dim] > lex[dim])
        continue;
    }

    assign_const(stmts_[i].xform, dim, lex2[dim] + amount);
  }
}


void Loop::setLexicalOrder(int dim, const std::set<int> &active, int starting_order) {
  if (active.size() == 0)
    return;

  // check for sanity of parameters
  if (dim < 0 || dim % 2 != 0)
    throw std::invalid_argument("invalid constant loop level to set lexicographical order");
  std::vector<int> lex;
  int ref_stmt_num;
  for (std::set<int>::iterator i = active.begin(); i != active.end(); i++) {
    if ((*i) < 0 || (*i) >= stmts_.size())
      throw std::invalid_argument("invalid statement number " + to_string(*i));
    if (dim >= stmts_[*i].xform.n_out())
      throw std::invalid_argument("invalid constant loop level to set lexicographical order");
    if (i == active.begin()) {
      lex = getLexicalOrder(*i);
      ref_stmt_num = *i;
    }
    else {
      std::vector<int> lex2 = getLexicalOrder(*i);
      for (int j = 0; j < dim; j+=2)
        if (lex[j] != lex2[j])
          throw std::invalid_argument("statements are not in the same sub loop nest");
    }
  }

  // sepearate statements by current loop level types
  int level = (dim+2)/2;
  std::map<std::pair<LoopLevelType, int>, std::set<int> > active_by_level_type;
  std::set<int> active_by_no_level;
  for (std::set<int>::iterator i = active.begin(); i != active.end(); i++) {
    if (level > stmts_[*i].levels.size())
      active_by_no_level.insert(*i);
    else
      active_by_level_type[std::make_pair(stmts_[*i].levels[level-1].first, stmts_[*i].levels[level-1].second)].insert(*i);
  }

  // further separate statements due to control dependences
  std::vector<std::set<int> > active_by_level_type_splitted;
  for (std::map<std::pair<LoopLevelType, int>, std::set<int> >::iterator i = active_by_level_type.begin(); i != active_by_level_type.end(); i++)
    active_by_level_type_splitted.push_back(i->second);
  for (std::set<int>::iterator i = active_by_no_level.begin(); i != active_by_no_level.end(); i++)
    for (int j = active_by_level_type_splitted.size() - 1; j >= 0; j--) {
      std::set<int> controlled, not_controlled;
      for (std::set<int>::iterator k = active_by_level_type_splitted[j].begin(); k != active_by_level_type_splitted[j].end(); k++) {
        std::vector<DependenceVector> dvs = dep_.getEdge(*i, *k);
        bool is_controlled = false;
        for (int kk = 0; kk < dvs.size(); kk++)
          if (dvs[kk].type = DEP_CONTROL) {
            is_controlled = true;
            break;
          }
        if (is_controlled)
          controlled.insert(*k);
        else
          not_controlled.insert(*k);
      }
      if (controlled.size() != 0 && not_controlled.size() != 0) {
        active_by_level_type_splitted.erase(active_by_level_type_splitted.begin() + j);
        active_by_level_type_splitted.push_back(controlled);
        active_by_level_type_splitted.push_back(not_controlled);
      }
    }
              
  // set lexical order separating loops with different loop types first
  if (active_by_level_type_splitted.size() + active_by_no_level.size() > 1) {
    int dep_dim = get_last_dep_dim_before(ref_stmt_num, level) + 1;

    Graph<std::set<int>, Empty> g;
    for (std::vector<std::set<int> >::iterator i = active_by_level_type_splitted.begin(); i != active_by_level_type_splitted.end(); i++)
      g.insert(*i);
    for (std::set<int>::iterator i = active_by_no_level.begin(); i != active_by_no_level.end(); i++) {
      std::set<int> t;
      t.insert(*i);
      g.insert(t);
    }
    for (int i = 0; i < g.vertex_.size(); i++)
      for (int j = i+1; j < g.vertex_.size(); j++) {
        bool connected = false;
        for (std::set<int>::iterator ii = g.vertex_[i].first.begin(); ii != g.vertex_[i].first.end(); ii++) {
          for (std::set<int>::iterator jj = g.vertex_[j].first.begin(); jj != g.vertex_[j].first.end(); jj++) {
            std::vector<DependenceVector> dvs = dep_.getEdge(*ii, *jj);
            for (int k = 0; k < dvs.size(); k++)
              if (dvs[k].is_control_dependence() ||
                  (dvs[k].is_data_dependence() && !dvs[k].has_been_carried_before(dep_dim))) {
                g.connect(i, j);
                connected = true;
                break;
              }
            if (connected)
              break;
          }
          if (connected)
            break;
        }
        connected = false;
        for (std::set<int>::iterator ii = g.vertex_[i].first.begin(); ii != g.vertex_[i].first.end(); ii++) {
          for (std::set<int>::iterator jj = g.vertex_[j].first.begin(); jj != g.vertex_[j].first.end(); jj++) {
            std::vector<DependenceVector> dvs = dep_.getEdge(*jj, *ii);
            for (int k = 0; k < dvs.size(); k++)
              if (dvs[k].is_control_dependence() ||
                  (dvs[k].is_data_dependence() && !dvs[k].has_been_carried_before(dep_dim))) {
                g.connect(j, i);
                connected = true;
                break;
              }
            if (connected)
              break;
          }
          if (connected)
            break;
        }
      }

    std::vector<std::set<int> > s = g.topoSort();
    if (s.size() != g.vertex_.size())
      throw loop_error("cannot separate statements with different loop types at loop level " + to_string(level));

    // assign lexical order
    int order = starting_order;
    for (int i = 0; i < s.size(); i++) {
      std::set<int> &cur_scc = g.vertex_[*(s[i].begin())].first;
      int sz = cur_scc.size();
      if (sz == 1) {
        int cur_stmt = *(cur_scc.begin());
        assign_const(stmts_[cur_stmt].xform, dim, order);
        for (int j = dim+2; j < stmts_[cur_stmt].xform.n_out(); j+=2)
          assign_const(stmts_[cur_stmt].xform, j, 0);
        order++;
      }
      else {
        setLexicalOrder(dim, cur_scc, order);
        order += sz;
      }
    }
  }
  // set lexical order seperating single iteration statements and loops
  else {
    std::set<int> true_singles;
    std::set<int> nonsingles;
    std::map<coef_t, std::set<int> > fake_singles;

    // sort out statements that do not require loops
    for(std::set<int>::iterator i = active.begin(); i != active.end(); i++) {
      Relation cur_IS = getNewIS(*i);
      if (is_single_iteration(cur_IS, dim+1)) {
        bool is_all_single = true;
        for (int j = dim+3; j < stmts_[*i].xform.n_out(); j+=2)
          if (!is_single_iteration(cur_IS, j)) {
            is_all_single = false;
            break;
          }
        if (is_all_single) 
          true_singles.insert(*i);
        else {
          try {
            fake_singles[get_const(cur_IS, dim+1, Set_Var)].insert(*i);
          }
          catch (const std::exception &e) {
            fake_singles[posInfinity].insert(*i);
          }
        }
      }
      else
        nonsingles.insert(*i);
    }

    // split nonsingles forcibly according to negative dependences present (loop unfusible)
    int dep_dim = get_dep_dim_of(ref_stmt_num, level);
    Graph<int, Empty> g2;
    for (std::set<int>::iterator i = nonsingles.begin(); i != nonsingles.end(); i++)
      g2.insert(*i);
    for (int i = 0; i < g2.vertex_.size(); i++)
      for (int j = i+1; j < g2.vertex_.size(); j++) {
        std::vector<DependenceVector> dvs = dep_.getEdge(g2.vertex_[i].first, g2.vertex_[j].first);
        for (int k = 0; k < dvs.size(); k++)
          if (dvs[k].is_control_dependence() ||
              (dvs[k].is_data_dependence() && dvs[k].has_negative_been_carried_at(dep_dim))) {
            g2.connect(i, j);
            break;
          }
        dvs = dep_.getEdge(g2.vertex_[j].first, g2.vertex_[i].first);
        for (int k = 0; k < dvs.size(); k++)
          if (dvs[k].is_control_dependence() ||
              (dvs[k].is_data_dependence() && dvs[k].has_negative_been_carried_at(dep_dim))) {
            g2.connect(j, i);
            break;
          }
      }
    
    std::vector<std::set<int> > s2 = g2.packed_topoSort();

    std::vector<std::set<int> > splitted_nonsingles;
    for (int i = 0; i < s2.size(); i++) {
      std::set<int> cur_scc;
      for (std::set<int>::iterator j = s2[i].begin(); j != s2[i].end(); j++)
        cur_scc.insert(g2.vertex_[*j].first);
      splitted_nonsingles.push_back(cur_scc);
    }
             
    // convert to dependence graph for grouped statements
    dep_dim = get_last_dep_dim_before(ref_stmt_num, level) + 1;
    Graph<std::set<int>, Empty> g;
    for (std::set<int>::iterator i = true_singles.begin(); i != true_singles.end(); i++) {
      std::set<int> t;
      t.insert(*i);
      g.insert(t);
    }
    for (int i = 0; i < splitted_nonsingles.size(); i++) {
      g.insert(splitted_nonsingles[i]);
    }   
    for (std::map<coef_t, std::set<int> >::iterator i = fake_singles.begin(); i != fake_singles.end(); i++)
      g.insert((*i).second);

    for (int i = 0; i < g.vertex_.size(); i++)
      for (int j = i + 1; j < g.vertex_.size(); j++) {
        bool connected = false;
        for (std::set<int>::iterator ii = g.vertex_[i].first.begin(); ii != g.vertex_[i].first.end(); ii++) {
          for (std::set<int>::iterator jj = g.vertex_[j].first.begin(); jj != g.vertex_[j].first.end(); jj++) {
            std::vector<DependenceVector> dvs = dep_.getEdge(*ii, *jj);
            for (int k = 0; k < dvs.size(); k++)
              if (dvs[k].is_control_dependence() ||
                  (dvs[k].is_data_dependence() && !dvs[k].has_been_carried_before(dep_dim))) {
                g.connect(i, j);
                connected = true;
                break;
              }
            if (connected)
              break;
          }
          if (connected)
            break;
        }
        connected = false;
        for (std::set<int>::iterator ii = g.vertex_[i].first.begin(); ii != g.vertex_[i].first.end(); ii++) {
          for (std::set<int>::iterator jj = g.vertex_[j].first.begin(); jj != g.vertex_[j].first.end(); jj++) {
            std::vector<DependenceVector> dvs = dep_.getEdge(*jj, *ii);
            for (int k = 0; k < dvs.size(); k++)
              if (dvs[k].is_control_dependence() ||
                  (dvs[k].is_data_dependence() && !dvs[k].has_been_carried_before(dep_dim))) {
                g.connect(j, i);
                connected = true;
                break;
              }
            if (connected)
              break;
          }
          if (connected)
            break;  
        }
      }
  
    // topological sort to obey dependence constraints
    std::vector<std::set<int> > s = g.topoSort();

    // assign lexical order
    int order = starting_order;
    for (int i = 0; i < s.size(); i++) {
      // translate each SCC into original statements
      std::set<int> cur_scc;
      for (std::set<int>::iterator j = s[i].begin(); j != s[i].end(); j++)
        copy(g.vertex_[*j].first.begin(), g.vertex_[*j].first.end(), inserter(cur_scc, cur_scc.begin()));

      // now assign the constant
      for(std::set<int>::iterator j = cur_scc.begin(); j != cur_scc.end(); j++)
        assign_const(stmts_[*j].xform, dim, order);
    
      if (cur_scc.size() > 1)
        setLexicalOrder(dim+2, cur_scc);
      else if (cur_scc.size() == 1) {
        int cur_stmt =*(cur_scc.begin());
        for (int j = dim+2; j < stmts_[cur_stmt].xform.n_out(); j+=2)
          assign_const(stmts_[cur_stmt].xform, j, 0);
      }

      if (cur_scc.size() > 0)
        order++;
    }
  }
}


void Loop::apply_xform() {
  std::set<int> active;
  for (int i = 0; i < stmts_.size(); i++)
    active.insert(i);
  apply_xform(active);
}


void Loop::apply_xform(int stmt_num) {
  std::set<int> active;
  active.insert(stmt_num);
  apply_xform(active);
}
   

void Loop::apply_xform(std::set<int> &active) {
  // invalidate saved codegen computation
  delete last_compute_cgr_;
  last_compute_cgr_ = NULL;
  delete last_compute_cg_;
  last_compute_cg_ = NULL;

  int max_n = 0;
  
  CG_outputBuilder *ocg = ir_->builder();
  for (std::set<int>::iterator i = active.begin(); i != active.end(); i++) {
    int n = stmts_[*i].levels.size();
    if (n > max_n)
      max_n = n;

    std::vector<int> lex = getLexicalOrder(*i);
    
    Relation mapping(2*n+1, n);
    F_And *f_root = mapping.add_and();
    for (int j = 1; j <= n; j++) {
      EQ_Handle h = f_root->add_EQ();
      h.update_coef(mapping.output_var(j), 1);
      h.update_coef(mapping.input_var(2*j), -1);
    }
    mapping = Composition(mapping, stmts_[*i].xform);
    mapping.simplify();

    // match omega input/output variables to variable names in the code
    for (int j = 1; j <= stmts_[*i].IS.n_set(); j++)
      mapping.name_input_var(j, stmts_[*i].IS.set_var(j)->name());
    for (int j = 1; j <= n; j++)
      mapping.name_output_var(j, tmp_loop_var_name_prefix + to_string(tmp_loop_var_name_counter+j-1));
    mapping.setup_names();

    std::vector<std::string> loop_vars;
    for (int j = 1; j <= stmts_[*i].IS.n_set(); j++)
      loop_vars.push_back(stmts_[*i].IS.set_var(j)->name());
    std::vector<CG_outputRepr *> subs = output_substitutions(ocg, Inverse(copy(mapping)), std::vector<std::pair<CG_outputRepr *, int> >(mapping.n_out(), std::make_pair(static_cast<CG_outputRepr *>(NULL), 0)));
    stmts_[*i].code = ocg->CreateSubstitutedStmt(0, stmts_[*i].code, loop_vars, subs);
    stmts_[*i].IS = Range(Restrict_Domain(mapping, stmts_[*i].IS));
    stmts_[*i].IS.simplify();
    
    // replace original transformation relation with straight 1-1 mapping
    mapping = Relation(n, 2*n+1);
    f_root = mapping.add_and();
    for (int j = 1; j <= n; j++) {
      EQ_Handle h = f_root->add_EQ();
      h.update_coef(mapping.output_var(2*j), 1);
      h.update_coef(mapping.input_var(j), -1);
    }
    for (int j = 1; j <= 2*n+1; j+=2) {
      EQ_Handle h = f_root->add_EQ();
      h.update_coef(mapping.output_var(j), 1);
      h.update_const(-lex[j-1]);
    }  
    stmts_[*i].xform = mapping;
  }
  
  tmp_loop_var_name_counter += max_n;
}


void Loop::removeDependence(int stmt_num_from, int stmt_num_to) {
  // check for sanity of parameters
  if (stmt_num_from >= stmts_.size())
    throw std::invalid_argument("invalid statement number " + to_string(stmt_num_from));
  if (stmt_num_to >= stmts_.size())
    throw std::invalid_argument("invalid statement number " + to_string(stmt_num_to));
    
  dep_.disconnect(stmt_num_from, stmt_num_to);
}


void Loop::addKnown(const Relation &cond) {
  // invalidate saved codegen computation
  delete last_compute_cgr_;
  last_compute_cgr_ = NULL;
  delete last_compute_cg_;
  last_compute_cg_ = NULL;
  
  int n1 = known_.n_set();

  Relation r = copy(cond);
  int n2 = r.n_set();

  if (n1 < n2)
    known_ = Extend_Set(known_, n2-n1);
  else if (n1 > n2)
    r = Extend_Set(r, n1-n2);

  known_ = Intersection(known_, r);
}

    
bool Loop::nonsingular(const std::vector<std::vector<int> > &T) {
  if (stmts_.size() == 0)
    return true;
  
  // check for sanity of parameters
  for (int i = 0; i < stmts_.size(); i++) {
    if (stmts_[i].levels.size() != dep_.num_dim())
      throw std::invalid_argument("nonsingular loop transformations must be applied to original perfect loop nest");
    for (int j = 0; j < stmts_[i].levels.size(); j++)
      if (stmts_[i].levels[j].first != NativeLevel)
        throw std::invalid_argument("nonsingular loop transformations must be applied to original perfect loop nest");
  }
  if (T.size() != dep_.num_dim())
    throw std::invalid_argument("invalid transformation matrix");
  for (int i = 0; i < stmts_.size(); i++)
    if (T[i].size() != dep_.num_dim() + 1 && T[i].size() != dep_.num_dim())
      throw std::invalid_argument("invalid transformation matrix");

  // invalidate saved codegen computation
  delete last_compute_cgr_;
  last_compute_cgr_ = NULL;
  delete last_compute_cg_;
  last_compute_cg_ = NULL;

  // build relation from matrix
  Relation mapping(2*dep_.num_dim()+1, 2*dep_.num_dim()+1);
  F_And *f_root = mapping.add_and();
  for (int i = 0; i < dep_.num_dim(); i++) {
    EQ_Handle h = f_root->add_EQ();
    h.update_coef(mapping.output_var(2*(i+1)), -1);
    for (int j = 0; j < dep_.num_dim(); j++)
      if (T[i][j] != 0) 
        h.update_coef(mapping.input_var(2*(j+1)), T[i][j]);
    if (T[i].size() == dep_.num_dim()+1)
      h.update_const(T[i][dep_.num_dim()]);
  }
  for (int i = 1; i <= 2*dep_.num_dim()+1; i+=2) {
    EQ_Handle h = f_root->add_EQ();
    h.update_coef(mapping.output_var(i), -1);
    h.update_coef(mapping.input_var(i), 1);
  }

  // update transformation relations
  for (int i = 0; i < stmts_.size(); i++)
    stmts_[i].xform = Composition(copy(mapping), stmts_[i].xform);
  
  // update dependence graph
  for (int i = 0; i < dep_.vertex_.size(); i++)
    for (DependenceGraph::EdgeList::iterator j = dep_.vertex_[i].second.begin(); j != dep_.vertex_[i].second.end(); j++) {
      std::vector<DependenceVector> dvs = j->second;
      for (int k = 0; k < dvs.size(); k++) {
        DependenceVector &dv = dvs[k];
        switch (dv.type) {
        case DEP_W2R:
        case DEP_R2W:
        case DEP_W2W:
        case DEP_R2R: {
          std::vector<coef_t> lbounds(dep_.num_dim()), ubounds(dep_.num_dim());
          for (int p = 0; p < dep_.num_dim(); p++) {
            coef_t lb = 0;
            coef_t ub = 0;
            for (int q = 0; q < dep_.num_dim(); q++) {
              if (T[p][q] > 0) {
                if (lb == -posInfinity || dv.lbounds[q] == -posInfinity)
                  lb = -posInfinity;
                else
                  lb += T[p][q] * dv.lbounds[q];
                if (ub == posInfinity || dv.ubounds[q] == posInfinity)
                  ub = posInfinity;
                else
                  ub += T[p][q] * dv.ubounds[q];
              }
              else if (T[p][q] < 0) {
                if (lb == -posInfinity || dv.ubounds[q] == posInfinity)
                  lb = -posInfinity;
                else
                  lb += T[p][q] * dv.ubounds[q];
                if (ub == posInfinity || dv.lbounds[q] == -posInfinity)
                  ub = posInfinity;
                else
                  ub += T[p][q] * dv.lbounds[q];
              }
            }
            if (T[p].size() == dep_.num_dim()+1) {
              if (lb != -posInfinity)
                lb += T[p][dep_.num_dim()];
              if (ub != posInfinity)
                ub += T[p][dep_.num_dim()];
            }
            lbounds[p] = lb;
            ubounds[p] = ub;
          }
          dv.lbounds = lbounds;
          dv.ubounds = ubounds;
          
          break;
        }
        default:
          ;
        }
      }
      j->second = dvs;
    }

  // set constant loop values
  std::set<int> active;
  for (int i = 0; i < stmts_.size(); i++)
    active.insert(i);
  setLexicalOrder(0, active);

  return true;
}
