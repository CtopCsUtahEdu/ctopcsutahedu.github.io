/*****************************************************************************
 Copyright (C) 2004-2011 Chun Chen
 All Rights Reserved.

 Purpose:
   Basic transformation algorithms.

 Notes:
 
 History:
   06/09/11 split from loop.cc, Chun Chen
*****************************************************************************/

#include "loop.hh"
#include "chill_error.hh"
#include <omega.h>
#include "omegatools.hh"

using namespace omega;

void Loop::original() {
  if (stmts_.size() == 0)
    return;

  std::vector<int> pi(stmts_[0].levels.size());
  for (int i = 0; i < pi.size(); i++)
    pi[i] = i+1;

  permute(pi);
}


void Loop::permute(const std::vector<int> &pi) {
  if (stmts_.size() == 0)
    return;

  permute(0, 0, pi);
}
  

void Loop::permute(int stmt_num, int level, const std::vector<int> &pi) {
  // check for sanity of parameters
  int starting_order;
  if (stmt_num < 0 || stmt_num >= stmts_.size())
    throw std::invalid_argument("invalid statement number " + to_string(stmt_num));
  std::set<int> active;
  if (level < 0 || level > stmts_[stmt_num].levels.size())
    throw std::invalid_argument("invalid loop level " + to_string(level));
  else if (level == 0) {
    for (int i = 0; i < stmts_.size(); i++)
      active.insert(i);
    level = 1;
    starting_order = 0;
  }
  else {
    std::vector<int> lex = getLexicalOrder(stmt_num);
    active = getStatements(lex, 2*level-2);
    starting_order = lex[2*level-2];
    lex[2*level-2]++;
    shiftLexicalOrder(lex, 2*level-2, active.size()-1);
  }
  std::vector<int> pi_inverse(pi.size(), 0);
  for (int i = 0; i < pi.size(); i++) {
    if (pi[i] >= level+pi.size() || pi[i] < level || pi_inverse[pi[i]-level] != 0)
      throw std::invalid_argument("invalid permuation");
    pi_inverse[pi[i]-level] = level + i;
  }
  for (std::set<int>::iterator i = active.begin(); i != active.end(); i++)
    if (level+pi.size()-1 > stmts_[*i].levels.size())
      throw std::invalid_argument("invalid permutation for statement " + to_string(*i));

  // invalidate saved codegen computation
  delete last_compute_cgr_;
  last_compute_cgr_ = NULL;
  delete last_compute_cg_;
  last_compute_cg_ = NULL;
  
  // Update transformation relations
  for (std::set<int>::iterator i = active.begin(); i != active.end(); i++) {
    int n = stmts_[*i].xform.n_out();
    Relation mapping(n, n);
    F_And *f_root = mapping.add_and();
    for (int j = 1; j <= 2*level-2; j++) {
      EQ_Handle h = f_root->add_EQ();
      h.update_coef(mapping.output_var(j), 1);
      h.update_coef(mapping.input_var(j), -1);
    }
    for (int j = level; j <= level+pi.size()-1; j++) {
      EQ_Handle h = f_root->add_EQ();
      h.update_coef(mapping.output_var(2*j), 1);
      h.update_coef(mapping.input_var(2*pi[j-level]), -1);
    }
    for (int j = level; j <= level+pi.size()-1; j++){
      EQ_Handle h = f_root->add_EQ();
      h.update_coef(mapping.output_var(2*j-1), 1);
      h.update_coef(mapping.input_var(2*j-1), -1);
    }
    for (int j = 2*(level+pi.size()-1)+1; j <= n; j++) {
      EQ_Handle h = f_root->add_EQ();
      h.update_coef(mapping.output_var(j), 1);
      h.update_coef(mapping.input_var(j), -1);
    }
    stmts_[*i].xform = Composition(mapping, stmts_[*i].xform);
    stmts_[*i].xform.simplify();
  }

  // get the permuation for dependence vectors
  std::vector<int> t;
  for (int i = 0; i < pi.size(); i++)
    if (stmts_[stmt_num].levels[pi[i]-1].first == NativeLevel)
      t.push_back(stmts_[stmt_num].levels[pi[i]-1].second);
  int max_dep_dim = -1;
  int min_dep_dim = dep_.num_dim();
  for (int i = 0; i < t.size(); i++) {
    if (t[i] > max_dep_dim)
      max_dep_dim = t[i];
    if (t[i] < min_dep_dim)
      min_dep_dim = t[i];
  }
  if (min_dep_dim > max_dep_dim)
    return;
  if (max_dep_dim - min_dep_dim + 1 != t.size())
    throw loop_error("cannot update the dependence graph after permuation");
  std::vector<int> dep_pi(dep_.num_dim());
  for (int i = 0; i < min_dep_dim; i++)
    dep_pi[i] = i;
  for (int i = min_dep_dim; i <= max_dep_dim; i++)
    dep_pi[i] = t[i-min_dep_dim];
  for (int i = max_dep_dim+1; i < dep_.num_dim(); i++)
    dep_pi[i] = i;  
  
  // update the dependence graph
  DependenceGraph g(dep_.num_dim());
  for (int i = 0; i < dep_.vertex_.size(); i++)
    g.insert();
  for (int i = 0; i < dep_.vertex_.size(); i++)
    for (DependenceGraph::EdgeList::iterator j = dep_.vertex_[i].second.begin(); j != dep_.vertex_[i].second.end(); j++) {
      if ((active.find(i) != active.end() && active.find(j->first) != active.end())) {
        std::vector<DependenceVector> dv = j->second;
        for (int k = 0; k < dv.size(); k++) {
          switch (dv[k].type) {
          case DEP_W2R:
          case DEP_R2W:
          case DEP_W2W:
          case DEP_R2R: {
            std::vector<coef_t> lbounds(dep_.num_dim());
            std::vector<coef_t> ubounds(dep_.num_dim());
            for (int d = 0; d < dep_.num_dim(); d++) {
              lbounds[d] = dv[k].lbounds[dep_pi[d]];
              ubounds[d] = dv[k].ubounds[dep_pi[d]];
            }
            dv[k].lbounds = lbounds;
            dv[k].ubounds = ubounds;
           break;
          }
          case DEP_CONTROL: {
            break;
          }
          default:
            throw loop_error("unknown dependence type");
          }
        }
        g.connect(i, j->first, dv);
      }
      else if (active.find(i) == active.end() && active.find(j->first) == active.end()) {
        std::vector<DependenceVector> dv = j->second;
        g.connect(i, j->first, dv);
      }
      else {
        std::vector<DependenceVector> dv = j->second;
        for (int k = 0; k < dv.size(); k++)
          switch (dv[k].type) {
          case DEP_W2R:
          case DEP_R2W:
          case DEP_W2W:
          case DEP_R2R: {
            for (int d = 0; d < dep_.num_dim(); d++)
              if (dep_pi[d] != d) {
                dv[k].lbounds[d] = -posInfinity;
                dv[k].ubounds[d] = posInfinity;
              }
            break;
          }
          case DEP_CONTROL:
            break;
          default:
            throw loop_error("unknown dependence type");
          }
        g.connect(i, j->first, dv);
      }
    }
  dep_ = g;

  // update loop level information
  for (std::set<int>::iterator i = active.begin(); i != active.end(); i++) {
    int cur_dep_dim = min_dep_dim;
    std::vector<std::pair<LoopLevelType, int> > new_loop_level(stmts_[*i].levels.size());
    for (int j = 1; j <= stmts_[*i].levels.size(); j++)
      if (j >= level && j < level+pi.size()) {
        switch (stmts_[*i].levels[pi_inverse[j-level]-1].first) {
        case NativeLevel:
          new_loop_level[j-1].first = NativeLevel;
          new_loop_level[j-1].second = cur_dep_dim++;
          break;
        case BlockLevel: {
          new_loop_level[j-1].first = BlockLevel;
          int ref_level = stmts_[*i].levels[pi_inverse[j-level]-1].second;
          if (ref_level >= level && ref_level < level+pi.size())
            new_loop_level[j-1].second = pi_inverse[ref_level-level];
          else
            new_loop_level[j-1].second = ref_level;
          break;
        }
        default:
          throw loop_error("unknown loop level information for statement " + to_string(*i));
        }
      }
      else {
        switch (stmts_[*i].levels[j-1].first) {
        case NativeLevel:
          new_loop_level[j-1].first = NativeLevel;
          new_loop_level[j-1].second = stmts_[*i].levels[j-1].second;
          break;
        case BlockLevel: {
          new_loop_level[j-1].first = BlockLevel;
          int ref_level = stmts_[*i].levels[j-1].second;
          if (ref_level >= level && ref_level < level+pi.size())
            new_loop_level[j-1].second = pi_inverse[ref_level-level];
          else
            new_loop_level[j-1].second = ref_level;
          break;
        }
        default:
          throw loop_error("unknown loop level information for statement " + to_string(*i));          
        }
      }
    stmts_[*i].levels = new_loop_level;
  }

  setLexicalOrder(2*level-2, active, starting_order);  
}


std::set<int> Loop::split(int stmt_num, int level, const Relation &cond) {
  // check for sanity of parameters
  if (stmt_num < 0 || stmt_num >= stmts_.size())
    throw std::invalid_argument("invalid statement " + to_string(stmt_num));
  if (level <= 0 || level > stmts_[stmt_num].levels.size())
    throw std::invalid_argument("invalid loop level " + to_string(level));

  // invalidate saved codegen computation
  delete last_compute_cgr_;
  last_compute_cgr_ = NULL;
  delete last_compute_cg_;
  last_compute_cg_ = NULL;
  
  std::set<int> result;
  int dim = 2*level-1;
  std::vector<int> lex = getLexicalOrder(stmt_num);
  std::set<int> same_loop = getStatements(lex, dim-1);

  Relation cond2 = copy(cond);
  cond2.simplify();
  cond2 = EQs_to_GEQs(cond2);
  Conjunct *c = cond2.single_conjunct();
  int cur_lex = lex[dim-1];
  for (GEQ_Iterator gi(c->GEQs()); gi; gi++) {
    int max_level = (*gi).max_tuple_pos();
    Relation single_cond(max_level);
    single_cond.and_with_GEQ(*gi);

    // TODO: should decide where to place newly created statements with
    // complementary split condition from dependence graph.
    bool place_after;
    if (max_level == 0)
      place_after = true;
    else if ((*gi).get_coef(cond2.set_var(max_level)) < 0)
      place_after = true;
    else
      place_after = false;
    
    // make adjacent lexical number available for new statements
    if (place_after) {
      lex[dim-1] = cur_lex+1;
      shiftLexicalOrder(lex, dim-1, 1);
    }
    else {
      lex[dim-1] = cur_lex-1;
      shiftLexicalOrder(lex, dim-1, -1);
    }

    // original statements with split condition,
    // new statements with complement of split condition
    int old_num_stmt = stmts_.size();
    std::map<int, int> what_stmt_num;
    apply_xform(same_loop);
    for (std::set<int>::iterator i = same_loop.begin(); i != same_loop.end(); i++) {
      int n = stmts_[*i].IS.n_set();
      Relation part1, part2;
      if (max_level > n) {
        part1 = copy(stmts_[*i].IS);
        part2 = Relation::False(n);
      }
      else {
        part1 = Intersection(copy(stmts_[*i].IS), Extend_Set(copy(single_cond), n-max_level));
        part2 = Intersection(copy(stmts_[*i].IS), Extend_Set(Complement(copy(single_cond)), n-max_level));
      }

      stmts_[*i].IS = part1;
      
      if (Intersection(copy(part2), Extend_Set(copy(known_), n-known_.n_set())).is_upper_bound_satisfiable()) {
        Statement new_stmt;
        new_stmt.code = stmts_[*i].code->clone();
        new_stmt.IS = part2;
        new_stmt.xform = copy(stmts_[*i].xform);
        if (place_after)
          assign_const(new_stmt.xform, dim-1, cur_lex+1);
        else
          assign_const(new_stmt.xform, dim-1, cur_lex-1);
        new_stmt.levels = stmts_[*i].levels;
        stmts_.push_back(new_stmt);
        dep_.insert();
        what_stmt_num[*i] = stmts_.size() - 1;
        if (*i == stmt_num)
          result.insert(stmts_.size() - 1);
      }
    }

    // update dependence graph
    int dep_dim = get_dep_dim_of(stmt_num, level);
    for (int i = 0; i < old_num_stmt; i++) {
      std::vector<std::pair<int, std::vector<DependenceVector> > > D;

      for (DependenceGraph::EdgeList::iterator j = dep_.vertex_[i].second.begin(); j != dep_.vertex_[i].second.end(); j++) {
        if (same_loop.find(i) != same_loop.end()) {
          if (same_loop.find(j->first) != same_loop.end()) {
            if (what_stmt_num.find(i) != what_stmt_num.end() && what_stmt_num.find(j->first) != what_stmt_num.end())
              dep_.connect(what_stmt_num[i], what_stmt_num[j->first], j->second);
            if (place_after && what_stmt_num.find(j->first) != what_stmt_num.end()) {
              std::vector<DependenceVector> dvs;
              for (int k = 0; k < j->second.size(); k++) {
                DependenceVector dv = j->second[k];
                if (dv.is_data_dependence() && dep_dim != -1) {
                  dv.lbounds[dep_dim] = -posInfinity;
                  dv.ubounds[dep_dim] = posInfinity;
                }
                dvs.push_back(dv);
              }
              if (dvs.size() > 0)
                D.push_back(std::make_pair(what_stmt_num[j->first], dvs));
            }
            else if (!place_after && what_stmt_num.find(i) != what_stmt_num.end()) {
              std::vector<DependenceVector> dvs;
              for (int k = 0; k < j->second.size(); k++) {
                DependenceVector dv = j->second[k];
                if (dv.is_data_dependence() && dep_dim != -1) {
                  dv.lbounds[dep_dim] = -posInfinity;
                  dv.ubounds[dep_dim] = posInfinity;
                }
                dvs.push_back(dv);
              }
              if (dvs.size() > 0)
                dep_.connect(what_stmt_num[i], j->first, dvs);

            }
          }
          else {
            if (what_stmt_num.find(i) != what_stmt_num.end())
              dep_.connect(what_stmt_num[i], j->first, j->second);
          }
        }
        else if (same_loop.find(j->first) != same_loop.end()) {
          if (what_stmt_num.find(j->first) != what_stmt_num.end())
            D.push_back(std::make_pair(what_stmt_num[j->first], j->second));
        }
      }

      for (int j = 0; j < D.size(); j++)
        dep_.connect(i, D[j].first, D[j].second);
    }
  }

  return result;
}


void Loop::skew(const std::set<int> &stmt_nums, int level, const std::vector<int> &skew_amount) {
  if (stmt_nums.size() == 0)
    return;
  
  // check for sanity of parameters
  int ref_stmt_num = *(stmt_nums.begin());
  for (std::set<int>::const_iterator i = stmt_nums.begin(); i != stmt_nums.end(); i++) {
    if (*i < 0 || *i >= stmts_.size())
      throw std::invalid_argument("invalid statement number " + to_string(*i));
    if (level < 1 || level > stmts_[*i].levels.size())
      throw std::invalid_argument("invalid loop level " + to_string(level));
    for (int j = stmts_[*i].levels.size(); j < skew_amount.size(); j++)
      if (skew_amount[j] != 0)
        throw std::invalid_argument("invalid skewing formula");
  }

  // invalidate saved codegen computation
  delete last_compute_cgr_;
  last_compute_cgr_ = NULL;
  delete last_compute_cg_;
  last_compute_cg_ = NULL;

  // set trasformation relations
  for (std::set<int>::const_iterator i = stmt_nums.begin(); i != stmt_nums.end(); i++) {
    int n = stmts_[*i].xform.n_out();
    Relation r(n,n);
    F_And *f_root = r.add_and();
    for (int j = 1; j <= n; j++)
      if (j != 2*level) {
        EQ_Handle h = f_root->add_EQ();
        h.update_coef(r.input_var(j), 1);
        h.update_coef(r.output_var(j), -1);
      }
    EQ_Handle h = f_root->add_EQ();
    h.update_coef(r.output_var(2*level), -1);
    for (int j = 0; j < skew_amount.size(); j++)
      if (skew_amount[j] != 0)
        h.update_coef(r.input_var(2*(j+1)), skew_amount[j]);
    
    stmts_[*i].xform = Composition(r, stmts_[*i].xform);
    stmts_[*i].xform.simplify();
  }

  // update dependence graph
  if (stmts_[ref_stmt_num].levels[level-1].first == NativeLevel) {
    int dep_dim = stmts_[ref_stmt_num].levels[level-1].second;
    for (std::set<int>::const_iterator i = stmt_nums.begin(); i != stmt_nums.end(); i++)
      for (DependenceGraph::EdgeList::iterator j = dep_.vertex_[*i].second.begin(); j != dep_.vertex_[*i].second.end(); j++)
        if (stmt_nums.find(j->first) != stmt_nums.end()) {
          // dependence between skewed statements
          std::vector<DependenceVector> dvs = j->second;
          for (int k = 0; k < dvs.size(); k++) {
            DependenceVector &dv = dvs[k];
            if (dv.is_data_dependence()) {
              coef_t lb = 0;
              coef_t ub = 0;
              for (int kk = 0; kk < skew_amount.size(); kk++) {
                int cur_dep_dim = get_dep_dim_of(*i, kk+1);
                if (skew_amount[kk] > 0) {
                  if (lb != -posInfinity &&
                      stmts_[*i].levels[kk].first == NativeLevel &&
                      dv.lbounds[cur_dep_dim] != -posInfinity)
                    lb += skew_amount[kk] * dv.lbounds[cur_dep_dim];
                  else {
                    if (cur_dep_dim != -1 && !(dv.lbounds[cur_dep_dim] == 0 && dv.ubounds[cur_dep_dim] == 0))
                      lb = -posInfinity;
                  }
                  if (ub != posInfinity &&
                      stmts_[*i].levels[kk].first == NativeLevel &&
                      dv.ubounds[cur_dep_dim] != posInfinity)
                    ub += skew_amount[kk] * dv.ubounds[cur_dep_dim];
                  else {
                    if (cur_dep_dim != -1 && !(dv.lbounds[cur_dep_dim] == 0 && dv.ubounds[cur_dep_dim] == 0))
                      ub = posInfinity;
                  }
                }
                else if (skew_amount[kk] < 0) {
                  if (lb != -posInfinity &&
                      stmts_[*i].levels[kk].first == NativeLevel &&
                      dv.ubounds[cur_dep_dim] != posInfinity)
                    lb += skew_amount[kk] * dv.ubounds[cur_dep_dim];
                  else {
                    if (cur_dep_dim != -1 && !(dv.lbounds[cur_dep_dim] == 0 && dv.ubounds[cur_dep_dim] == 0))
                      lb = -posInfinity;
                  }
                  if (ub != posInfinity &&
                      stmts_[*i].levels[kk].first == NativeLevel &&
                      dv.lbounds[cur_dep_dim] != -posInfinity)
                    ub += skew_amount[kk] * dv.lbounds[cur_dep_dim];
                  else {
                    if (cur_dep_dim != -1 && !(dv.lbounds[cur_dep_dim] == 0 && dv.ubounds[cur_dep_dim] == 0))
                      ub = posInfinity;
                  }
                }
              }
              dv.lbounds[dep_dim] = lb;
              dv.ubounds[dep_dim] = ub;
            }
          }
          j->second = dvs;
        }
        else {
          // dependence from skewed statement to unskewed statement becomes jumbled,
          // put distance value at skewed dimension to unknown
          std::vector<DependenceVector> dvs = j->second;
          for (int k = 0; k < dvs.size(); k++) {
            DependenceVector &dv = dvs[k];
            if (dv.is_data_dependence()) {
              dv.lbounds[dep_dim] = -posInfinity;
              dv.ubounds[dep_dim] = posInfinity;
            }
          }
          j->second = dvs;
        }
    for (int i = 0; i < dep_.vertex_.size(); i++)
      if (stmt_nums.find(i) == stmt_nums.end())
        for (DependenceGraph::EdgeList::iterator j = dep_.vertex_[i].second.begin(); j != dep_.vertex_[i].second.end(); j++)
          if (stmt_nums.find(j->first) != stmt_nums.end()) {
            // dependence from unskewed statement to skewed statement becomes jumbled,
            // put distance value at skewed dimension to unknown
            std::vector<DependenceVector> dvs = j->second;
            for (int k = 0; k < dvs.size(); k++) {
              DependenceVector &dv = dvs[k];
              if (dv.is_data_dependence()) {
                dv.lbounds[dep_dim] = -posInfinity;
                dv.ubounds[dep_dim] = posInfinity;
              }
            }
            j->second = dvs;
          }
  }
}


void Loop::shift(const std::set<int> &stmt_nums, int level, int shift_amount) {
  if (stmt_nums.size() == 0)
    return;
  
  // check for sanity of parameters
  int ref_stmt_num = *(stmt_nums.begin());
  for (std::set<int>::const_iterator i = stmt_nums.begin(); i != stmt_nums.end(); i++) {
    if (*i < 0 || *i >= stmts_.size())
      throw std::invalid_argument("invalid statement number " + to_string(*i));
    if (level < 1 || level > stmts_[*i].levels.size())
      throw std::invalid_argument("invalid loop level " + to_string(level));
  }

  // do nothing
  if (shift_amount == 0)
    return;

  // invalidate saved codegen computation
  delete last_compute_cgr_;
  last_compute_cgr_ = NULL;
  delete last_compute_cg_;
  last_compute_cg_ = NULL;
  
  // set trasformation relations
  for (std::set<int>::const_iterator i = stmt_nums.begin(); i != stmt_nums.end(); i++) {
    int n = stmts_[*i].xform.n_out();
    
    Relation r(n, n);
    F_And *f_root = r.add_and();
    for (int j = 1; j <= n; j++) {
      EQ_Handle h = f_root->add_EQ();
      h.update_coef(r.input_var(j), 1);
      h.update_coef(r.output_var(j), -1);
      if (j == 2*level)
        h.update_const(shift_amount);
    }
    
    stmts_[*i].xform = Composition(r, stmts_[*i].xform);
    stmts_[*i].xform.simplify();
  }

  // update dependence graph
  if (stmts_[ref_stmt_num].levels[level-1].first == NativeLevel) {
    int dep_dim = stmts_[ref_stmt_num].levels[level-1].second;
    for (std::set<int>::const_iterator i = stmt_nums.begin(); i != stmt_nums.end(); i++)
      for (DependenceGraph::EdgeList::iterator j = dep_.vertex_[*i].second.begin(); j != dep_.vertex_[*i].second.end(); j++)
        if (stmt_nums.find(j->first) == stmt_nums.end()) {
          // dependence from shifted statement to unshifted statement
          std::vector<DependenceVector> dvs = j->second;
          for (int k = 0; k < dvs.size(); k++) {
            DependenceVector &dv = dvs[k];
            if (dv.is_data_dependence()) {
              if (dv.lbounds[dep_dim] != -posInfinity)
                dv.lbounds[dep_dim] -= shift_amount;
              if (dv.ubounds[dep_dim] != posInfinity)
                dv.ubounds[dep_dim] -= shift_amount;
            }
          }
          j->second = dvs;
        }
    for (int i = 0; i < dep_.vertex_.size(); i++)
      if (stmt_nums.find(i) == stmt_nums.end())
        for (DependenceGraph::EdgeList::iterator j = dep_.vertex_[i].second.begin(); j != dep_.vertex_[i].second.end(); j++)
          if (stmt_nums.find(j->first) != stmt_nums.end()) {
            // dependence from unshifted statement to shifted statement
            std::vector<DependenceVector> dvs = j->second;
            for (int k = 0; k < dvs.size(); k++) {
              DependenceVector &dv = dvs[k];
              if (dv.is_data_dependence()) {
                if (dv.lbounds[dep_dim] != -posInfinity)
                  dv.lbounds[dep_dim] += shift_amount;
                if (dv.ubounds[dep_dim] != posInfinity)
                  dv.ubounds[dep_dim] += shift_amount;
              }
            }
            j->second = dvs;
          }
  }
}


void Loop::scale(const std::set<int> &stmt_nums, int level, int scale_amount) {
  std::vector<int> skew_amount(level, 0);
  skew_amount[level-1] = scale_amount;
  skew(stmt_nums, level, skew_amount);
}


void Loop::reverse(const std::set<int> &stmt_nums, int level) {
  scale(stmt_nums, level, -1);
}


void Loop::fuse(const std::set<int> &stmt_nums, int level) {
  if (stmt_nums.size() == 0 || stmt_nums.size() == 1)
    return;

  // invalidate saved codegen computation
  delete last_compute_cgr_;
  last_compute_cgr_ = NULL;
  delete last_compute_cg_;
  last_compute_cg_ = NULL;
  
  int dim = 2*level-1;

  // check for sanity of parameters
  std::vector<int> ref_lex;
  std::pair<LoopLevelType, int> ref_ll;
  for (std::set<int>::const_iterator i = stmt_nums.begin(); i != stmt_nums.end(); i++) {
    if (*i < 0 || *i >= stmts_.size())
      throw std::invalid_argument("invalid statement number " + to_string(*i));
    if (level < 1 || level > (stmts_[*i].xform.n_out()-1)/2)
      throw std::invalid_argument("invalid loop level " + to_string(level));
    if (i == stmt_nums.begin()) {
      ref_lex = getLexicalOrder(*i);
      ref_ll = stmts_[*i].levels[level-1];
    }
    else {
      std::vector<int> lex = getLexicalOrder(*i);
      for (int j = 0; j < dim-1; j+=2)
        if (lex[j] != ref_lex[j])
          throw std::invalid_argument("statements for fusion must be in the same level-" + to_string(level-1) + " subloop");
      if (stmts_[*i].levels[level-1] != ref_ll)
        throw std::invalid_argument("loops to be fused are of different type");
    }
  }

  // collect lexicographical order values from to-be-fused statements
  std::set<int> lex_values;
  for (std::set<int>::const_iterator i = stmt_nums.begin(); i != stmt_nums.end(); i++) {
    std::vector<int> lex = getLexicalOrder(*i);
    lex_values.insert(lex[dim-1]);
  }
  if (lex_values.size() == 1)
    return;

  // negative dependence would prevent fusion
  int dep_dim = get_dep_dim_of(*stmt_nums.begin(), level);
  for (std::set<int>::iterator i = lex_values.begin(); i != lex_values.end(); i++) {
    ref_lex[dim-1] = *i;
    std::set<int> a = getStatements(ref_lex, dim-1);
    std::set<int>::iterator j = i;
    j++;
    for (; j != lex_values.end(); j++) {
      ref_lex[dim-1] = *j;
      std::set<int> b = getStatements(ref_lex, dim-1);
      for (std::set<int>::iterator ii = a.begin(); ii != a.end(); ii++)
        for (std::set<int>::iterator jj = b.begin(); jj != b.end(); jj++) {
          std::vector<DependenceVector> dvs;
          dvs = dep_.getEdge(*ii, *jj);
          for (int k = 0; k < dvs.size(); k++)
            if (dvs[k].isCarried(dep_dim) && dvs[k].hasNegative(dep_dim))
              throw loop_error("loop error: statements " + to_string(*ii) + " and " + to_string(*jj) + " cannot be fused together due to negative dependence");
          dvs = dep_.getEdge(*jj, *ii);
          for (int k = 0; k < dvs.size(); k++)
            if (dvs[k].isCarried(dep_dim) && dvs[k].hasNegative(dep_dim))
              throw loop_error("loop error: statements " + to_string(*jj) + " and " + to_string(*ii) + " cannot be fused together due to negative dependence");
        }
    }
  }
  
  // collect all other lexicographical order values from the subloop
  // enclosing these to-be-fused loops
  std::set<int> same_loop = getStatements(ref_lex, dim-3);
  std::set<int> other_lex_values;
  for (std::set<int>::iterator i = same_loop.begin(); i != same_loop.end(); i++) {
    std::vector<int> lex = getLexicalOrder(*i);
    if (lex_values.find(lex[dim-1]) == lex_values.end())
      other_lex_values.insert(lex[dim-1]);
  }

  // update to-be-fused loops due to dependence cycle
  Graph<std::set<int>, Empty> g;
  {
    std::set<int> t;
    for (std::set<int>::iterator i = lex_values.begin(); i != lex_values.end(); i++) {
      ref_lex[dim-1] = *i;
      std::set<int> t2 = getStatements(ref_lex, dim-1);
      std::set_union(t.begin(), t.end(), t2.begin(), t2.end(), inserter(t, t.begin()));
    }
    g.insert(t);
  }
  for (std::set<int>::iterator i = other_lex_values.begin(); i != other_lex_values.end(); i++) {
    ref_lex[dim-1] = *i;
    std::set<int> t = getStatements(ref_lex, dim-1);
    g.insert(t);
  }
  for (int i = 0; i < g.vertex_.size(); i++)
    for (int j = i+1; j < g.vertex_.size(); j++)
      for (std::set<int>::iterator ii = g.vertex_[i].first.begin(); ii != g.vertex_[i].first.end(); ii++)
        for (std::set<int>::iterator jj = g.vertex_[j].first.begin(); jj != g.vertex_[j].first.end(); jj++) {
          std::vector<DependenceVector> dvs;
          dvs = dep_.getEdge(*ii, *jj);
          for (int k = 0; k < dvs.size(); k++)
            if (dvs[k].isCarried(dep_dim)) {
              g.connect(i, j);
              break;
            }
          dvs = dep_.getEdge(*jj, *ii);
          for (int k = 0; k < dvs.size(); k++)
            if (dvs[k].isCarried(dep_dim)) {
              g.connect(j, i);
              break;
            }
        }
  std::vector<std::set<int> > s = g.topoSort();
  int fused_lex_value = 0;
  for (int i = 0; i < s.size(); i++)
    if (s[i].find(0) != s[i].end()) {
      // now add additional lexicographical order values
      for (std::set<int>::iterator j = s[i].begin(); j != s[i].end(); j++)
        if (*j != 0) {
          int stmt = *(g.vertex_[*j].first.begin());
          std::vector<int> lex = getLexicalOrder(stmt);
          lex_values.insert(lex[dim-1]);
        }

      if (s.size() > 1) {
        if (i == 0) {
          int min_lex_value;
          for (std::set<int>::iterator j = s[i+1].begin(); j != s[i+1].end(); j++) {
            int stmt = *(g.vertex_[*j].first.begin());
            std::vector<int> lex = getLexicalOrder(stmt);
            if (j == s[i+1].begin())
              min_lex_value = lex[dim-1];
            else if (lex[dim-1] < min_lex_value)
              min_lex_value = lex[dim-1];
          }
          fused_lex_value = min_lex_value - 1;
        }
        else {
          int max_lex_value;
          for (std::set<int>::iterator j = s[i-1].begin(); j != s[i-1].end(); j++) {
            int stmt = *(g.vertex_[*j].first.begin());
            std::vector<int> lex = getLexicalOrder(stmt);
            if (j == s[i-1].begin())
              max_lex_value = lex[dim-1];
            else if (lex[dim-1] > max_lex_value)
              max_lex_value = lex[dim-1];
          }
          fused_lex_value = max_lex_value + 1;
        }
      }

      break;
    }
          
  // sort the newly updated to-be-fused lexicographical order values
  std::vector<int> ordered_lex_values;
  for (std::set<int>::iterator i = lex_values.begin(); i != lex_values.end(); i++)
    ordered_lex_values.push_back(*i);
  std::sort(ordered_lex_values.begin(), ordered_lex_values.end());
            
  // make sure internal loops inside to-be-fused loops have the same
  // lexicographical order before and after fusion
  std::vector<std::pair<int, int> > inside_lex_range(ordered_lex_values.size());
  for (int i = 0; i < ordered_lex_values.size(); i++) {
    ref_lex[dim-1] = ordered_lex_values[i];
    std::set<int> the_stmts = getStatements(ref_lex, dim-1);
    std::set<int>::iterator j = the_stmts.begin();
    std::vector<int> lex = getLexicalOrder(*j);
    int min_inside_lex_value = lex[dim+1];
    int max_inside_lex_value = lex[dim+1];
    j++;
    for (; j != the_stmts.end(); j++) {
      std::vector<int> lex = getLexicalOrder(*j);
      if (lex[dim+1] < min_inside_lex_value)
        min_inside_lex_value = lex[dim+1];
      if (lex[dim+1] > max_inside_lex_value)
        max_inside_lex_value = lex[dim+1];
    }
    inside_lex_range[i].first = min_inside_lex_value;
    inside_lex_range[i].second = max_inside_lex_value;
  }
  for (int i = 1; i < ordered_lex_values.size(); i++)
    if (inside_lex_range[i].first <= inside_lex_range[i-1].second) {
      int shift_lex_value = inside_lex_range[i-1].second - inside_lex_range[i].first + 1;
      ref_lex[dim-1] = ordered_lex_values[i];
      ref_lex[dim+1] = inside_lex_range[i].first;
      shiftLexicalOrder(ref_lex, dim+1, shift_lex_value);
      inside_lex_range[i].first += shift_lex_value;
      inside_lex_range[i].second += shift_lex_value;
    }
      
  // set lexicographical order for fused loops
  for (std::set<int>::iterator i = same_loop.begin(); i != same_loop.end(); i++) {
    std::vector<int> lex = getLexicalOrder(*i);
    if (lex_values.find(lex[dim-1]) != lex_values.end())
      assign_const(stmts_[*i].xform, dim-1, fused_lex_value);      
  }
  
  // no need to update dependence graph
  ;
}
    

void Loop::distribute(const std::set<int> &stmt_nums, int level) {
  if (stmt_nums.size() == 0 || stmt_nums.size() == 1)
    return;

  // invalidate saved codegen computation
  delete last_compute_cgr_;
  last_compute_cgr_ = NULL;
  delete last_compute_cg_;
  last_compute_cg_ = NULL;
  
  int dim = 2*level-1;

  // check for sanity of parameters
  std::vector<int> ref_lex;
  std::pair<LoopLevelType, int> ref_ll;
  for (std::set<int>::const_iterator i = stmt_nums.begin(); i != stmt_nums.end(); i++) {
    if (*i < 0 || *i >= stmts_.size())
      throw std::invalid_argument("invalid statement number " + to_string(*i));
    if (level < 1 || level > (stmts_[*i].xform.n_out()-1)/2)
      throw std::invalid_argument("invalid loop level " + to_string(level));
    if (i == stmt_nums.begin()) {
      ref_lex = getLexicalOrder(*i);
      ref_ll = stmts_[*i].levels[level-1];
    }
    else {
      std::vector<int> lex = getLexicalOrder(*i);
      for (int j = 0; j <= dim-1; j+=2)
        if (lex[j] != ref_lex[j])
          throw std::invalid_argument("statements for distribution must be in the same level-" + to_string(level) + " subloop");
      if (stmts_[*i].levels[level-1] != ref_ll)
        throw std::invalid_argument("loops to be distributed are of different type");
    }
  }

  // find SCC in the to-be-distributed loop
  int dep_dim = get_dep_dim_of(*stmt_nums.begin(), level);
  std::set<int> same_loop = getStatements(ref_lex, dim-1);
  Graph<int, Empty> g;
  for (std::set<int>::iterator i = same_loop.begin(); i != same_loop.end(); i++)
    g.insert(*i);
  for (int i = 0; i < g.vertex_.size(); i++)
    for (int j = i+1; j < g.vertex_.size(); j++) {
      std::vector<DependenceVector> dvs;
      dvs = dep_.getEdge(g.vertex_[i].first, g.vertex_[j].first);
      for (int k = 0; k < dvs.size(); k++)
        if (dvs[k].isCarried(dep_dim)) {
          g.connect(i, j);
          break;
        }
      dvs = dep_.getEdge(g.vertex_[j].first, g.vertex_[i].first);
      for (int k = 0; k < dvs.size(); k++)
        if (dvs[k].isCarried(dep_dim)) {
          g.connect(j, i);
          break;
        }
    }
  std::vector<std::set<int> > s = g.topoSort();
  
  // find statements that cannot be distributed due to dependence cycle
  Graph<std::set<int>, Empty> g2;
  for (int i = 0; i < s.size(); i++) {
    std::set<int> t;
    for (std::set<int>::iterator j = s[i].begin(); j != s[i].end(); j++)
      if (stmt_nums.find(g.vertex_[*j].first) != stmt_nums.end())
        t.insert(g.vertex_[*j].first);
    if (!t.empty())
      g2.insert(t);
  }
  for (int i = 0; i < g2.vertex_.size(); i++)
    for (int j = i+1; j < g2.vertex_.size(); j++)
      for (std::set<int>::iterator ii = g2.vertex_[i].first.begin(); ii != g2.vertex_[i].first.end(); ii++)
        for (std::set<int>::iterator jj = g2.vertex_[j].first.begin(); jj != g2.vertex_[j].first.end(); jj++) {
          std::vector<DependenceVector> dvs;
          dvs = dep_.getEdge(*ii, *jj);
          for (int k = 0; k < dvs.size(); k++)
            if (dvs[k].isCarried(dep_dim)) {
              g2.connect(i, j);
              break;
            }
          dvs = dep_.getEdge(*jj, *ii);
          for (int k = 0; k < dvs.size(); k++)
            if (dvs[k].isCarried(dep_dim)) {
              g2.connect(j, i);
              break;
            }
        }
  std::vector<std::set<int> > s2 = g2.topoSort();

  // nothing to distribute
  if (s2.size() == 1)
    throw loop_error("loop error: no statement can be distributed due to dependence cycle");
  
  std::vector<std::set<int> > s3;
  for (int i = 0; i < s2.size(); i++) {
    std::set<int> t;
    for (std::set<int>::iterator j = s2[i].begin(); j != s2[i].end(); j++)
      std::set_union(t.begin(), t.end(), g2.vertex_[*j].first.begin(), g2.vertex_[*j].first.end(), inserter(t, t.begin()));
    s3.push_back(t);
  }

  // associate other affected statements with the right distributed statements
  for (std::set<int>::iterator i = same_loop.begin(); i != same_loop.end(); i++)
    if (stmt_nums.find(*i) == stmt_nums.end()) {
      bool is_inserted = false;
      int potential_insertion_point = 0;
      for (int j = 0; j < s3.size(); j++) {
        for (std::set<int>::iterator k = s3[j].begin(); k != s3[j].end(); k++) {
          std::vector<DependenceVector> dvs;
          dvs = dep_.getEdge(*i, *k);
          for (int kk = 0; kk < dvs.size(); kk++)
            if (dvs[kk].isCarried(dep_dim)) {
              s3[j].insert(*i);
              is_inserted = true;
              break;
            }
          dvs = dep_.getEdge(*k, *i);
          for (int kk = 0; kk < dvs.size(); kk++)
            if (dvs[kk].isCarried(dep_dim))
              potential_insertion_point = j;
        }
        if (is_inserted)
          break;
      }

      if (!is_inserted)
        s3[potential_insertion_point].insert(*i);
    }

  // set lexicographical order after distribution
  int order = ref_lex[dim-1];
  shiftLexicalOrder(ref_lex, dim-1, s3.size()-1);
  for (std::vector<std::set<int> >::iterator i = s3.begin(); i != s3.end(); i++) {
    for (std::set<int>::iterator j = (*i).begin(); j != (*i).end(); j++)
      assign_const(stmts_[*j].xform, dim-1, order);
    order++;
  }

  // no need to update dependence graph
  ;
}
