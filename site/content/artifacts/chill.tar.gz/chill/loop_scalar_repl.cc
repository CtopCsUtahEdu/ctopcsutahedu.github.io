/*****************************************************************************
 Copyright (C) 2011 Chun Chen
 All Rights Reserved.

 Purpose:
   Scalar replacement.

 Notes:
   Scalar replacement can be thought as datacopy or datacopy_pipelined with
 discrete footprint. Generator concept can be found in "Improving register
 allocation for subscripted variables" by D. Callahan, S. Carr and
 K. Kennedy.

   Currently the control flow structure inside the statement is ignored,
 thus extra load/store might be generated if original references are never
 touched. It might cause exceptions that otherwise won't appear in the
 original code for data touched by load/store under conditions, One solution
 is to use "valid" flags and guard those replacements.

 History:
   06/09/11 Created by Chun Chen
*****************************************************************************/

#include "loop.cc"
#include "omegatools.hh"

using namespace omega;

std::set<int> Loop::scalar_replacement_inner(int stmt_num) {
  // check for sanity of parameters
  if (stmt_num < 0 || stmt_num >= stmts_.size())
    throw std::invalid_argument("invalid statement number " + to_string(stmt_num));
  int level = stmts_[stmt_num].levels.size();
  std::set<int> subloop = getSubLoopNest(stmt_num, level);
  for (std::set<int>::iterator i = subloop.begin(); i != subloop.end(); )
    if (stmts_[*i].levels.size() > level)
      throw std::invalid_argument("statement " + to_string(stmt_num) + " does not belong to innermost loop");
  
  std::map<int, std::vector<IR_Array_Ref *> > refs;
  for (std::set<int>::iterator i = subloop.begin(); i != subloop.end(); i++)
    refs[*i] = ir_->FindArrayRef(stmts_[i].code);
    




  
}
